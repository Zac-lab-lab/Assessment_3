document.addEventListener('DOMContentLoaded', function() {
    const terminalInput = document.getElementById('terminal-input');
    const submitButton = document.getElementById('submit-command');
    const outputDiv = document.getElementById('output-lines');
    const promptSpan = document.getElementById('prompt');

    // CTF State
    let currentPath = '/home/trainee';
    let currentUser = 'guest';
    let awaitingPassword = false;
    let attemptingUser = '';
    let hasDevopsKey = false;
    let hasSubmittedKey = false;

    // Hardcoded filesystem and responses
    const FILESYSTEM = {
        '/': ['home'],
        '/home': ['trainee', 'devops'],
        '/home/trainee': ['documents', '.config'],
        '/home/trainee/documents': ['server_notes.txt', 'maintenance_logs.txt', 'todo.txt'],
        '/home/trainee/.config': ['.env'],
        '/home/devops': ['user_flag.txt', '.ssh'],
        '/home/devops/.ssh': ['id_rsa'],
        '/root': ['root_flag.txt']
    };

    const FILE_CONTENTS = {
        '/home/trainee/.config/.env': 'DB_HOST=localhost\nDB_PORT=5432\n# DevOps credentials below:\nDEVOPS_USER=devops\nDEVOPS_PASS=S3cr3tP@ss\n',
        '/home/trainee/documents/server_notes.txt': 'Server Notes:\n-----------------\n1. Updated server configurations\n2. Implemented new security protocols\n3. Review hidden directories regularly\n',
        '/home/trainee/documents/maintenance_logs.txt': 'Maintenance Logs:\n------------------\n2024-03-15: Moved sensitive files to .config\n2024-03-14: Security audit performed\n',
        '/home/trainee/documents/todo.txt': 'TODO List:\n-----------\n1. Check .config for important files\n2. Update security protocols\n3. Review system access\n',
        '/home/devops/user_flag.txt': 'UOW{devOps_user_flag_here}',
        '/home/devops/.ssh/id_rsa': '-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEAx4UbaDzY5xjW6hc9jwN0mX33XpTDVW9WqHp5AKaRbtAC3DqX\nIXFMPgw3K45jxRb93f8tv9vL3rD9CUG1Gv4FM+o7ds7FRES5RTjv2RT/JVNJCoqF\nol8+ngLqRZCyBtQN7zYByWMRirPGoDUqdPYrj2yxiPDgUFTjr2jBTWezs+9FHVF9\ncgYXpXMKMrL/MFkCb1DtKGb6M6ZmCXfKj0W39V9Nxia9Mn6Z7gJ/Z+1MEQwqCB0Q\n/Qn1IVCwVPk7K4QEI3PIkXiOQ4JRex6Zh8Bf14KBYtJB4NnLXUqF9IAvZF1G1CqN\nuRXP+OJ5Gg+F77ehNwZjjNIcw+z+LzwwdaKYhwIDAQABAoIBAQCn9yV05JMHks/H\nKZYbIv77yahHbGCR36qWRJAE2kTaYfyRAUi7qk7dj5pq1hJFwYuVJ1xFx9mfjoj5\nmQ4J/+I+FeM4e7VlHgsyy5sPXwWQ8bXQfGKe8F0WY+ONy+7ivG5v4GVJ7qMkI9Df\nEYuQI9U/XxVZ4RYX9XMxbCdW7tveBQYZDNVqw3UMS6/VbDYyJLbVZ3VcI9p4YPBW\nBxvGh7UAL4Z0Z1XHXv6aM4oMM/9wB+ld8hHGGQRyMOKbDE3bYbzCYw8LYK4VRoRR\nnmnAp6mLhP5Kb+qukOVGS5L2UH6QQjJ/qYKZ4oQCSWyOkNr4++R2X95Kv7cVT3R5\nmm5yHyJBAoGBAPxP7eFtHV3NOKs7RTqFCz7IJHx5ZL8uqHpmC9r4wMIncCY2Ea6F\nXjIwZkae/26f/S5Hh9W5QHHVhYZls7cAuso4v4LI4Bmm0qSZMqE6qCXCTWOI6eCZ\nFtHGu8g18pkCB5ubPqtQuyYGvMqouf1LZ4lHwYhZHBGQHqZ6kn8xWkXHAoGBAMpQ\n8PQaZKxG/Q4FW1ZQiN0SxgDB99oGC4Q6zofgn1rWt8Pg2nRDUtxKZlxG1IKoYV6T\nVzmjf0Hl/bHxZTR5Xd1QjbZgFi+7LlzMvDqpQqmo5/A5TZHqcNf3jvWf8a6mcYJ1\n2Cm/o8Ajqwq6hZKXhfhM9qO5Ym6gO6AYykD/W8nhAoGBAOg/r4iBpYMvQVj5HtWH\n2/oJo7pBPuH4jqpz/8xXDsqF1nDNxEwB6wAYqz1/d0lX/5eRoALHtB3UqHpIm2m/\n8Lb+j+sXKZ6aWkgqx5f4GxR6kYYBZ8OWMQyNxkZ1iXNB9yEkLk9sOcDzlXnLXkjA\noB7PL+H+mvWjAq5DRF5TMXpHAoGABSKiiWX7ewxw4Dwxb5V/j3eWmgb0LJpIG+rz\nTtYz0B9yNuuqNQCzCE5SHcrBCGWwGQxLcE3t1kQqC5J4PHhnKPWW4qkIRTzEYYzV\noRCNB7pmLPdHxOZ5/qaGUl5B3mKV0L9I3tx4dWIR4MRsKOAKEn0zA5bOw7I3zLHT\nGZHkPoECgYBd4FPudhcD3Z3/7iS8NlrnkBJ6Cw9FDOkCUGvtXZ7ta7KqHQO3lKRq\nJvO0IiRvkh3m3eT6wjJqB9C9xq7mnsFxNFd+KGstaxp5J3CovA7dz9VBBvxRbP5y\n+LjR/PmCqbKs5YCxcBHIqWqF5YAK3HJ7e4URZYb5L8Bk3YKuKV8gcw==\n-----END RSA PRIVATE KEY-----',
        '/root/root_flag.txt': 'UOW{root_access_achieved}'
    };

    const CREDENTIALS = {
        'trainee': 'Passw0rd!',
        'devops': 'S3cr3tP@ss'
    };

    function handleCommand() {
        const command = terminalInput.value.trim();
        if (!command) return;

        // Handle password input for SSH
        if (awaitingPassword) {
            const outputLine = document.createElement('div');
            outputLine.className = 'command-output';
            
            if (CREDENTIALS[attemptingUser] === command) {
                currentUser = attemptingUser;
                currentPath = `/home/${attemptingUser}`;
                outputLine.textContent = `Welcome to Ubuntu 22.04.2 LTS (GNU/Linux 5.19.0-38-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

Last login: ${new Date().toLocaleString()}

Connection established as ${attemptingUser} user.`;
            } else {
                outputLine.textContent = 'Access denied. Wrong password.';
            }
            
            outputDiv.appendChild(outputLine);
            awaitingPassword = false;
            attemptingUser = '';
            terminalInput.type = 'text';
            terminalInput.value = '';
            promptSpan.textContent = `${currentUser}@${currentPath}$`;
            return;
        }

        // Display command (except for password input)
        const commandLine = document.createElement('div');
        commandLine.className = 'command-output';
        commandLine.textContent = `${promptSpan.textContent} ${command}`;
        outputDiv.appendChild(commandLine);

        // Process command
        const output = processCommand(command);
        
        // Display output
        const outputLine = document.createElement('div');
        outputLine.className = 'command-output';
        outputLine.innerHTML = output;
        outputDiv.appendChild(outputLine);

        // Clear input
        terminalInput.value = '';
        
        // Update prompt if not awaiting password
        if (!awaitingPassword) {
            promptSpan.textContent = `${currentUser}@${currentPath}$`;
        }
    }

    function processCommand(command) {
        // Handle /home/trainee directory
        if (currentPath === '/home/trainee') {
            if (command.startsWith('ls -')) {
                return '.\n..\n.config\ndocuments';
            }
            if (command === 'ls') {
                return 'documents';
            }
        }
        
        // Handle /home/trainee/.config directory
        if (currentPath === '/home/trainee/.config') {
            if (command.startsWith('ls -')) {
                return '.\n..\n.env';
            }
            if (command === 'ls') {
                return '.env';
            }
            if (command === 'cat .env') {
                return '# Environment Variables\nDB_HOST=localhost\nDB_PORT=5432\n# DevOps Access\nDEVOPS_USER=devops\nDEVOPS_PASS=S3cr3tP@ss\n# Other Variables\nTEMP_DIR=/tmp\nLOG_LEVEL=debug';
            }
        }
        
        // Handle /home/devops directory - with fixed output
        if (currentPath === '/home/devops') {
            if (command.startsWith('ls -')) {
                return '.\n..\nuser_flag.txt\n.ssh';
            }
            if (command === 'ls') {
                return 'user_flag.txt';
            }
        }
        
        const parts = command.split(' ');
        const cmd = parts[0];

        switch(cmd) {
            case 'ls':
                if (FILESYSTEM[currentPath]) {
                    // Only show non-hidden files/directories
                    return FILESYSTEM[currentPath]
                        .filter(item => !item.startsWith('.'))
                        .join('  ');
                }
                return '';

            case 'ls -la':
            case 'ls -al':
            case 'ls -a':
                if (currentPath in FILESYSTEM) {
                    const output = [];
                    output.push('total 8');
                    output.push(`drwxr-xr-x 1 ${currentUser} ${currentUser} 4096 Mar 18 12:00 .`);
                    output.push(`drwxr-xr-x 1 ${currentUser} ${currentUser} 4096 Mar 18 12:00 ..`);
                    
                    // Get ALL items from the current directory and sort them
                    const items = [...FILESYSTEM[currentPath]].sort();
                    
                    // Add each item with proper formatting
                    for (const item of items) {
                        const isDir = FILESYSTEM[`${currentPath}/${item}`] !== undefined;
                        const type = isDir ? 'd' : '-';
                        output.push(`${type}rwxr-xr-x 1 ${currentUser} ${currentUser} 4096 Mar 18 12:00 ${item}`);
                    }
                    
                    return output.join('\n');
                }
                return `total 0\ndrwxr-xr-x 1 ${currentUser} ${currentUser} 4096 Mar 18 12:00 .\ndrwxr-xr-x 1 ${currentUser} ${currentUser} 4096 Mar 18 12:00 ..`;

            case 'cd':
                const newPath = parts[1];
                if (!newPath) return currentPath;
                if (newPath === '..') {
                    const pathParts = currentPath.split('/');
                    pathParts.pop();
                    currentPath = pathParts.join('/') || '/';
                    return '';
                }
                const fullPath = newPath.startsWith('/') ? newPath : `${currentPath}/${newPath}`;
                if (FILESYSTEM[fullPath]) {
                    currentPath = fullPath;
                    return '';
                }
                return 'Directory not found';

            case 'cat':
                const filePath = parts[1].startsWith('/') ? parts[1] : `${currentPath}/${parts[1]}`;
                if (FILE_CONTENTS[filePath]) {
                    if (filePath.includes('user_flag.txt') && currentUser !== 'devops') {
                        return 'Permission denied - Try logging in as devops user';
                    }
                    if (filePath.includes('root_flag.txt') && currentUser !== 'root') {
                        return 'Permission denied - Need root access';
                    }
                    return FILE_CONTENTS[filePath];
                }
                return 'File not found';

            case 'ssh':
                if (parts[1] === 'devops@192.168.1.100' || parts[1] === 'trainee@192.168.1.100') {
                    const user = parts[1].split('@')[0];
                    awaitingPassword = true;
                    attemptingUser = user;
                    terminalInput.type = 'password';
                    promptSpan.textContent = `${user}@192.168.1.100's password:`;
                    return `The authenticity of host '192.168.1.100' can't be established.
ECDSA key fingerprint is SHA256:uNiVztksCsDhcc0u9e8BujQXVUpKZIDTMczCvj3tD2s
Are you sure you want to continue connecting (yes/no/[fingerprint])? yes

Warning: Permanently added '192.168.1.100' (ECDSA) to the list of known hosts.
${user}@192.168.1.100's password:`;
                }
                if ((parts[1] === 'root@192.168.1.100' && parts[2] === '-i' && parts[3] === 'id_rsa') ||
                    (parts[1] === '-i' && parts[2] === 'id_rsa' && parts[3] === 'root@192.168.1.100')) {
                    if (currentUser === 'devops') {
                        if (hasSubmittedKey) {
                            currentUser = 'root';
                            currentPath = '/root';
                            return `Welcome to Ubuntu 22.04.2 LTS (GNU/Linux 5.19.0-38-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

Last login: ${new Date().toLocaleString()}

Connection established as root user.`;
                        } else {
                            return 'Permission denied - You must submit the SSH key in the "Submit SSH Key" section first!';
                        }
                    }
                    return 'Permission denied - Need devops access first';
                }
                return 'Invalid SSH command';

            case 'help':
                return 'Available commands:\nls - List directory contents\ncd - Change directory\ncat - View file contents\nssh - Connect to server\nhelp - Show this help message';

            default:
                return 'Command not found. Type "help" for available commands.';
        }
    }

    function submitFlag() {
        const flagInput = document.getElementById('flag-input');
        const flag = flagInput.value.trim();
        const resultDiv = document.getElementById('flag-result');

        if (flag === 'UOW{devOps_user_flag_here}' || flag === 'UOW{root_access_achieved}') {
            showMatrixEffect();
            resultDiv.textContent = 'Correct flag!';
            resultDiv.style.color = '#00ff00';
            setTimeout(() => {
                flagInput.value = '';
                resultDiv.textContent = '';
            }, 3000);
        } else {
            resultDiv.textContent = 'Incorrect flag';
            resultDiv.style.color = '#ff0000';
        }
    }

    function submitKey() {
        const keyInput = document.getElementById('key-input');
        const key = keyInput.value.trim();
        const resultDiv = document.getElementById('key-result');

        if (key.includes('BEGIN RSA PRIVATE KEY') && key.includes('END RSA PRIVATE KEY')) {
            showMatrixEffect();
            resultDiv.textContent = 'Correct key! You can now use: ssh -i id_rsa root@192.168.1.100';
            resultDiv.style.color = '#00ff00';
            hasSubmittedKey = true;
            setTimeout(() => {
                keyInput.value = '';
                resultDiv.textContent = '';
            }, 3000);
        } else {
            resultDiv.textContent = 'Invalid key';
            resultDiv.style.color = '#ff0000';
        }
    }

    function showMatrixEffect() {
        const matrixDiv = document.createElement('div');
        matrixDiv.className = 'matrix-effect';
        
        for (let i = 0; i < 100; i++) {
            const span = document.createElement('span');
            span.textContent = getRandomChar();
            span.style.left = `${Math.random() * 100}%`;
            span.style.animationDelay = `${Math.random() * 2}s`;
            matrixDiv.appendChild(span);
        }

        document.body.appendChild(matrixDiv);

        setTimeout(() => {
            document.body.removeChild(matrixDiv);
        }, 3000);
    }

    function getRandomChar() {
        const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン';
        return chars.charAt(Math.floor(Math.random() * chars.length));
    }

    // Event listeners
    submitButton.addEventListener('click', handleCommand);
    terminalInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            handleCommand();
        }
    });

    document.querySelector('button[onclick="submitFlag()"]').onclick = submitFlag;
    document.querySelector('button[onclick="submitKey()"]').onclick = submitKey;

    // Focus input on load
    terminalInput.focus();
});