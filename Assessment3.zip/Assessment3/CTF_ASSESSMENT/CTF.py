import streamlit as st
import logging
from streamlit_javascript import st_javascript
import json
from datetime import datetime
import os

logging.basicConfig(level=logging.DEBUG)

# Store credentials and flags
USERS = {
    'trainee': 'Passw0rd!',
    'devops': 'DevOps2024!'
}

FLAGS = {
    'user_flag': 'UOW{devOps_user_flag_here}',
    'root_flag': 'UOW{root_access_achieved}'
}

# Simulated file system - completely restructured
FILE_SYSTEM = {
    '/': ['home'],
    '/home': ['trainee', 'devops'],
    '/home/trainee': ['documents', '.config'],
    '/home/trainee/.config': ['.env'],
    '/home/trainee/documents': ['server_notes.txt', 'maintenance_logs.txt', 'todo.txt'],
    '/home/trainee/documents/server_notes.txt': '''Server Notes:
-----------------
1. Updated server configurations
2. Implemented new security protocols
3. Review hidden directories regularly
''',
    '/home/trainee/documents/maintenance_logs.txt': '''Maintenance Logs:
------------------
2024-03-15: Moved sensitive files to .config
2024-03-14: Security audit performed
''',
    '/home/trainee/documents/todo.txt': '''[PROTECTED FILE]
Please enter password to view contents.''',
    '/home/trainee/documents/todo.txt.decrypted': '''TODO List:
-----------
1. Change devops SSH password to: DevOps2024!
2. Implement file encryption for sensitive data
3. Update security protocols
4. Check .ssh directory for potential vulnerabilities
5. Review system access logs''',
    '/home/trainee/.config/.env': '''# Environment Variables
DB_HOST=localhost
DB_PORT=5432
# Protected File Access
TODO_USER=devops
TODO_PASS=S3cr3tP@ss
# Other Variables
TEMP_DIR=/tmp
LOG_LEVEL=debug''',
    '/home/devops': ['user_flag.txt', '.ssh'],
    '/home/devops/.ssh': ['id_rsa'],
    '/home/devops/user_flag.txt': 'UOW{devOps_user_flag_here}',
    '/home/devops/.ssh/id_rsa': '''-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEAx4UbaDzY5xjW6hc9jwN0mX33XpTDVW9WqHp5AKaRbtAC3DqX
IXFMPgw3K45jxRb93f8tv9vL3rD9CUG1Gv4FM+o7ds7FRES5RTjv2RT/JVNJCoqF
ol8+ngLqRZCyBtQN7zYByWMRirPGoDUqdPYrj2yxiPDgUFTjr2jBTWezs+9FHVF9
cgYXpXMKMrL/MFkCb1DtKGb6M6ZmCXfKj0W39V9Nxia9Mn6Z7gJ/Z+1MEQwqCB0Q
/Qn1IVCwVPk7K4QEI3PIkXiOQ4JRex6Zh8Bf14KBYtJB4NnLXUqF9IAvZF1G1CqN
uRXP+OJ5Gg+F77ehNwZjjNIcw+z+LzwwdaKYhwIDAQABAoIBAQCn9yV05JMHks/H
KZYbIv77yahHbGCR36qWRJAE2kTaYfyRAUi7qk7dj5pq1hJFwYuVJ1xFx9mfjoj5
mQ4J/+I+FeM4e7VlHgsyy5sPXwWQ8bXQfGKe8F0WY+ONy+7ivG5v4GVJ7qMkI9Df
EYuQI9U/XxVZ4RYX9XMxbCdW7tveBQYZDNVqw3UMS6/VbDYyJLbVZ3VcI9p4YPBW
BxvGh7UAL4Z0Z1XHXv6aM4oMM/9wB+ld8hHGGQRyMOKbDE3bYbzCYw8LYK4VRoRR
nmnAp6mLhP5Kb+qukOVGS5L2UH6QQjJ/qYKZ4oQCSWyOkNr4++R2X95Kv7cVT3R5
mm5yHyJBAoGBAPxP7eFtHV3NOKs7RTqFCz7IJHx5ZL8uqHpmC9r4wMIncCY2Ea6F
XjIwZkae/26f/S5Hh9W5QHHVhYZls7cAuso4v4LI4Bmm0qSZMqE6qCXCTWOI6eCZ
FtHGu8g18pkCB5ubPqtQuyYGvMqouf1LZ4lHwYhZHBGQHqZ6kn8xWkXHAoGBAMpQ
8PQaZKxG/Q4FW1ZQiN0SxgDB99oGC4Q6zofgn1rWt8Pg2nRDUtxKZlxG1IKoYV6T
Vzmjf0Hl/bHxZTR5Xd1QjbZgFi+7LlzMvDqpQqmo5/A5TZHqcNf3jvWf8a6mcYJ1
2Cm/o8Ajqwq6hZKXhfhM9qO5Ym6gO6AYykD/W8nhAoGBAOg/r4iBpYMvQVj5HtWH
2/oJo7pBPuH4jqpz/8xXDsqF1nDNxEwB6wAYqz1/d0lX/5eRoALHtB3UqHpIm2m/
8Lb+j+sXKZ6aWkgqx5f4GxR6kYYBZ8OWMQyNxkZ1iXNB9yEkLk9sOcDzlXnLXkjA
oB7PL+H+mvWjAq5DRF5TMXpHAoGABSKiiWX7ewxw4Dwxb5V/j3eWmgb0LJpIG+rz
TtYz0B9yNuuqNQCzCE5SHcrBCGWwGQxLcE3t1kQqC5J4PHhnKPWW4qkIRTzEYYzV
oRCNB7pmLPdHxOZ5/qaGUl5B3mKV0L9I3tx4dWIR4MRsKOAKEn0zA5bOw7I3zLHT
GZHkPoECgYBd4FPudhcD3Z3/7iS8NlrnkBJ6Cw9FDOkCUGvtXZ7ta7KqHQO3lKRq
JvO0IiRvkh3m3eT6wjJqB9C9xq7mnsFxNFd+KGstaxp5J3CovA7dz9VBBvxRbP5y
+LjR/PmCqbKs5YCxcBHIqWqF5YAK3HJ7e4URZYb5L8Bk3YKuKV8gcw==
-----END RSA PRIVATE KEY-----''',
    '/root': ['root_flag.txt'],
    '/root/root_flag.txt': 'UOW{root_access_achieved}'
}

# Initialize session state
if 'current_path' not in st.session_state:
    st.session_state.current_path = '/home/trainee'
if 'logged_in_user' not in st.session_state:
    st.session_state.logged_in_user = 'trainee'
if 'command_history' not in st.session_state:
    st.session_state.command_history = []
if 'output_history' not in st.session_state:
    st.session_state.output_history = []
if 'awaiting_password' not in st.session_state:
    st.session_state.awaiting_password = False
if 'ssh_user' not in st.session_state:
    st.session_state.ssh_user = None
if 'todo_password_prompt' not in st.session_state:
    st.session_state.todo_password_prompt = False
if 'todo_authenticated' not in st.session_state:
    st.session_state.todo_authenticated = False
if 'key_submitted' not in st.session_state:
    st.session_state.key_submitted = False

TARGET_IP = '192.168.1.100'

# Add this CSS for the terminal look
st.markdown("""
<style>
    .stApp {
        background-color: #1a1a1a;
    }
    .terminal-window {
        background-color: #000000;
        border-radius: 6px;
        box-shadow: 0 0 10px rgba(0,0,0,0.5);
        margin: 20px;
        padding: 20px;
        border: 1px solid #333;
        font-family: 'Courier New', monospace;
        color: #00ff00;
        min-height: 400px;
    }
    .terminal-header {
        background-color: #2d2d2d;
        padding: 8px;
        margin: -20px -20px 20px -20px;
        border-bottom: 1px solid #333;
        display: flex;
        align-items: center;
    }
    .terminal-dots {
        display: flex;
        gap: 6px;
        margin-right: 12px;
    }
    .terminal-dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
    }
    .dot-red { background-color: #ff5f56; }
    .dot-yellow { background-color: #ffbd2e; }
    .dot-green { background-color: #27c93f; }
    .terminal-content {
        white-space: pre-wrap;
        line-height: 1.5;
    }
    .stTextInput > div > div > input {
        background-color: #000000 !important;
        color: #00ff00 !important;
        font-family: 'Courier New', monospace !important;
        border: none !important;
        padding: 0 !important;
        width: 100% !important;
    }
    .matrix-effect {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.9);
        z-index: 1000;
        pointer-events: none;
        overflow: hidden;
        display: none;
    }
    .matrix-effect span {
        position: absolute;
        top: -100px;
        color: #0f0;
        font-family: 'Courier New', monospace;
        font-size: 24px;
        text-shadow: 0 0 10px #0f0;
        animation: matrix-drop 2s linear infinite;
    }
</style>
""", unsafe_allow_html=True)

def process_command(command):
    # Store the original user and path for command history
    original_user = st.session_state.logged_in_user
    original_path = st.session_state.current_path
    
    if not command:
        return ''
    
    current_path = st.session_state.current_path
    output = None

    # Handle help command
    if command.strip() == 'help':
        return '''Available Commands:
-----------------
ls          - List files in current directory
ls -la      - List all files (including hidden) in current directory
cd          - Change directory (e.g., cd documents, cd .., cd .config)
cat         - View file contents (e.g., cat todo.txt, cat .env)
ssh         - Connect to remote server (e.g., ssh trainee@192.168.1.100)
help        - Show this help message'''

    # Handle SSH command
    elif command.startswith('ssh'):
        parts = command.split()
        target = None
        for part in parts:
            if '@192.168.1.100' in part:
                target = part
                break
                
        if target:
            username = target.split('@')[0]
            if username == 'root':
                if not st.session_state.key_submitted:
                    return 'Permission denied. Please submit the SSH key first.'
                if '-i' in command and 'id_rsa' in command:
                    st.session_state.logged_in_user = 'root'
                    st.session_state.current_path = '/root'
                    return f'Welcome to SecureStack Industries\nLast login: {datetime.now().strftime("%a %b %d %H:%M:%S %Y")}'
                return 'Permission denied. Please use the SSH key with: ssh -i id_rsa root@192.168.1.100'
            elif username in USERS:
                st.session_state.awaiting_password = True
                st.session_state.ssh_user = username
                return f"{username}@192.168.1.100's password:"
        return 'ssh: Could not resolve hostname. Connection failed'
    
    # Handle password input for SSH
    elif st.session_state.awaiting_password:
        if command == USERS[st.session_state.ssh_user]:
            st.session_state.logged_in_user = st.session_state.ssh_user
            st.session_state.current_path = f'/home/{st.session_state.ssh_user}'
            st.session_state.awaiting_password = False
            st.session_state.ssh_user = None
            return f'Welcome to SecureStack Industries\nLast login: {datetime.now().strftime("%a %b %d %H:%M:%S %Y")}'
        st.session_state.awaiting_password = False
        st.session_state.ssh_user = None
        return 'Permission denied, please try again.'
    
    # Handle todo.txt password
    elif st.session_state.todo_password_prompt:
        if command.strip() == 'S3cr3tP@ss':
            st.session_state.todo_authenticated = True
            st.session_state.todo_password_prompt = False
            return '''Correct password!

TODO List:
-----------
1. Change devops SSH password to: DevOps2024!
2. Implement file encryption for sensitive data
3. Update security protocols
4. Check .ssh directory for potential vulnerabilities
5. Review system access logs'''
        st.session_state.todo_password_prompt = False
        return 'Incorrect password.'

    # Handle cd command
    elif command.startswith('cd'):
        path = command.split(' ', 1)[1] if len(command.split(' ', 1)) > 1 else ''
        if path == '..':
            # Move up one directory
            current_parts = current_path.rstrip('/').split('/')
            if len(current_parts) > 2:  # Don't go above /home
                st.session_state.current_path = '/'.join(current_parts[:-1])
            return ''
        
        # Construct new path
        new_path = os.path.normpath(os.path.join(current_path, path))
        if new_path in FILE_SYSTEM:
            st.session_state.current_path = new_path
            return ''
        return 'cd: no such file or directory'

    # Handle cat command
    elif command.startswith('cat'):
        filename = command.split(' ', 1)[1] if len(command.split(' ', 1)) > 1 else ''
        full_path = os.path.join(current_path, filename)
        
        if filename == '.env' and current_path.endswith('.config'):
            return '''# Environment Variables
DB_HOST=localhost
DB_PORT=5432
# Protected File Access
TODO_USER=devops
TODO_PASS=S3cr3tP@ss'''
        
        if filename == 'todo.txt' and current_path.endswith('documents'):
            if st.session_state.todo_authenticated:
                return '''TODO List:
-----------
1. Change devops SSH password to: DevOps2024!
2. Implement file encryption for sensitive data
3. Update security protocols
4. Check .ssh directory for potential vulnerabilities
5. Review system access logs'''
            else:
                st.session_state.todo_password_prompt = True
                return '[PROTECTED FILE]\nPlease enter password to view contents.'

        if filename == 'server_notes.txt' and current_path.endswith('documents'):
            return '''Server Notes:
-----------------
1. Updated server configurations
2. Implemented new security protocols
3. Review hidden directories regularly'''

        if filename == 'maintenance_logs.txt' and current_path.endswith('documents'):
            return '''Maintenance Logs:
------------------
2024-03-15: Moved sensitive files to .config
2024-03-14: Security audit performed'''
        
        if filename == 'user_flag.txt' and current_path.endswith('devops'):
            return FLAGS['user_flag']
            
        if filename == 'id_rsa' and current_path.endswith('.ssh'):
            return FILE_SYSTEM['/home/devops/.ssh/id_rsa']
            
        if filename == 'root_flag.txt' and current_path == '/root':
            return FLAGS['root_flag']
            
        return f"cat: {filename}: No such file or directory"

    # Handle directory listing commands
    elif command.startswith('ls'):
        if current_path.endswith('trainee'):
            if '-l' in command or '-la' in command or '-al' in command:
                return '''.
..
documents
.config'''
            return 'documents'
            
        if current_path.endswith('.config'):
            return '.env'
            
        if current_path.endswith('documents'):
            return '''server_notes.txt
maintenance_logs.txt
todo.txt'''
            
        if current_path.endswith('devops'):
            if '-l' in command or '-la' in command or '-al' in command:
                return '''.
..
user_flag.txt
.ssh'''
            return 'user_flag.txt'
            
        if current_path.endswith('.ssh'):
            return 'id_rsa'
            
        if current_path == '/root':
            return 'root_flag.txt'
            
        return ''

    return output

def main():
    # Create terminal window
    st.markdown("""
    <div class="terminal-window">
        <div class="terminal-header">
            <div class="terminal-dots">
                <div class="terminal-dot dot-red"></div>
                <div class="terminal-dot dot-yellow"></div>
                <div class="terminal-dot dot-green"></div>
            </div>
            Terminal
        </div>
        <div class="terminal-content">
            <div style="color: #00ff00;">Welcome to the CTF Challenge!</div>
            <div style="color: #00ff00;">Initial credentials: trainee:Passw0rd!</div>
            <div style="color: #00ff00;">Target IP: 192.168.1.100</div>
            <div style="color: #00ff00;">Try: ssh trainee@192.168.1.100</div>
            <div class="command-history">
    """, unsafe_allow_html=True)
    
    # Update command history display with minimal spacing
    for i, ((prompt, cmd), out) in enumerate(zip(st.session_state.command_history, st.session_state.output_history)):
        # Display command with original prompt
        st.markdown(f"""
        <div style="color: #00ff00;">
            {prompt}{cmd}
        </div>
        """, unsafe_allow_html=True)
        
        # Only display output if it exists
        if out:
            st.markdown(f"""
            <div style="color: #00ff00;">
                {out}
            </div>
            """, unsafe_allow_html=True)
    
    # Command input
    command = st.text_input(
        "",
        placeholder=f"{st.session_state.logged_in_user}@{TARGET_IP}:{st.session_state.current_path}$ ",
        key="command_input",
        on_change=handle_command
    )
    
    st.markdown('</div></div>', unsafe_allow_html=True)
    
    # Submission sections
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="submission-section">
            <h3>Submit Flag</h3>
        </div>
        """, unsafe_allow_html=True)
        flag_input = st.text_input("Enter flag:", key="flag_input")
        if st.button("Submit Flag"):
            if flag_input in FLAGS.values():
                if flag_input == FLAGS['root_flag']:
                    st.markdown("""
                    <div style='padding: 20px; background-color: #0f0; color: black; text-align: center; font-size: 24px; font-weight: bold; border-radius: 10px; animation: pulse 2s infinite;'>
                        🎉 Machine pwned! Great job! 🎉
                    </div>
                    <style>
                        @keyframes pulse {
                            0% { transform: scale(1); }
                            50% { transform: scale(1.05); }
                            100% { transform: scale(1); }
                        }
                    </style>
                    """, unsafe_allow_html=True)
                else:
                    st.success("Correct flag!")
            else:
                st.error("Incorrect flag")
    
    with col2:
        st.markdown("""
        <div class="submission-section">
            <h3>Submit SSH Key</h3>
        </div>
        """, unsafe_allow_html=True)
        key_input = st.text_area("Paste SSH private key:", key="key_input")
        if st.button("Submit Key"):
            # Remove all whitespace for comparison
            cleaned_input = ''.join(key_input.split())
            stored_key = ''.join(FILE_SYSTEM['/home/devops/.ssh/id_rsa'].split())
            
            if cleaned_input == stored_key:
                st.session_state.key_submitted = True
                st.success(f"Correct key! You can now use: ssh root@{TARGET_IP}")
            else:
                st.error("Invalid key")

def handle_command():
    """Process command when Enter is pressed"""
    command = st.session_state.command_input
    if command:
        # Create the prompt string
        prompt = f"{st.session_state.logged_in_user}@{TARGET_IP}:{st.session_state.current_path}$ "
        
        # Don't show password in command history
        if st.session_state.awaiting_password:
            display_command = '*' * len(command)
            st.session_state.command_history.append((prompt, display_command))
        else:
            st.session_state.command_history.append((prompt, command))
        
        # Process command and store output
        output = process_command(command)
        if output:  # Only add to history if there's output
            st.session_state.output_history.append(output)
        
        # Clear input after processing
        st.session_state.command_input = ""

if __name__ == '__main__':
    main()