import streamlit as st
import os
from PIL import Image
import io
import base64
from datetime import datetime
import time

# Revert to original color palette and update CSS
st.markdown("""
<style>
    /* Original Theme Colors */
    :root {
        --bg-primary: #1a1a1a;
        --bg-secondary: #2d2d2d;
        --accent: #4CAF50;
        --text-primary: #ffffff;
        --text-secondary: #b3b3b3;
    }

    /* Global Styles with more spacing */
    .stApp {
        background-color: var(--bg-primary);
        color: var(--text-primary);
        padding: 2rem;
    }
    
    /* Header Styling with more space */
    h1, h2, h3 {
        color: var(--text-primary);
        font-weight: 600;
        letter-spacing: -0.5px;
        padding: 1.5rem 0;
        margin-bottom: 2rem;
        border-bottom: 2px solid var(--bg-secondary);
    }
    
    /* Upload Section with increased spacing */
    .upload-section {
        background-color: var(--bg-secondary);
        padding: 2.5rem;
        border-radius: 1rem;
        margin-bottom: 3rem;
        border: 2px dashed var(--accent);
        transition: all 0.3s ease;
    }
    
    /* Gallery Grid with more breathing room */
    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 2rem;
        padding: 1.5rem;
        margin-top: 2rem;
    }
    
    .gallery-item {
        position: relative;
        background-color: var(--bg-secondary);
        border-radius: 1rem;
        overflow: hidden;
        transition: all 0.3s ease;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .gallery-item:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
    }
    
    /* Button Styling */
    .stButton button {
        background-color: var(--accent);
        color: white;
        border: none;
        padding: 0.6rem 1.2rem;
        border-radius: 0.5rem;
        font-weight: 500;
        transition: all 0.2s ease;
        width: 100%;
    }
    
    .stButton button:hover {
        filter: brightness(110%);
        transform: translateY(-1px);
    }
    
    /* Selectbox Styling */
    .stSelectbox > div > div {
        background-color: var(--bg-secondary);
        color: var(--text-primary);
        border: 1px solid var(--accent);
        border-radius: 0.5rem;
    }
    
    /* Image Info Overlay */
    .image-info {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(15, 23, 42, 0.9);
        padding: 0.75rem;
        color: var(--text-primary);
        font-size: 0.9rem;
        backdrop-filter: blur(4px);
    }

    /* File Uploader */
    .stFileUploader {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: var(--bg-secondary);
    }

    /* Expander */
    .streamlit-expanderHeader {
        background-color: var(--bg-secondary);
        border-radius: 0.5rem;
        color: var(--text-primary);
    }

    /* Folder Summary Section */
    .folder-summary {
        background-color: var(--bg-secondary);
        border: 2px dashed var(--accent);
        border-radius: 1rem;
        padding: 1.5rem;
        margin: 1rem 0;
    }
    
    .folder-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        margin: 1rem 0;
    }
    
    .stat-card {
        background-color: var(--bg-secondary);
        padding: 1rem;
        border-radius: 0.5rem;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .stat-number {
        font-size: 1.5rem;
        font-weight: bold;
        color: var(--accent);
    }
    
    .stat-label {
        color: var(--text-secondary);
        font-size: 0.9rem;
    }
    
    .folder-detail {
        background-color: var(--bg-secondary);
        padding: 0.75rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    
    /* Updated Gallery Styling */
    .gallery-item {
        background-color: var(--bg-secondary);
        border-radius: 1rem;
        padding: 1.5rem;
        margin: 2rem 0;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .gallery-item img {
        width: 100%;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
    }
    
    .image-info {
        padding: 1rem;
        background-color: var(--bg-secondary);
        border-radius: 0.5rem;
        margin-top: 0.5rem;
    }
    
    hr {
        margin: 2rem 0;
        border-color: var(--bg-secondary);
    }

    /* Gallery Item Styling */
    .gallery-item {
        background-color: var(--bg-secondary);
        border-radius: 1rem;
        padding: 2rem;
        margin: 2.5rem 0;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    
    .gallery-item img {
        width: 100%;
        max-width: 1200px;
        border-radius: 0.5rem;
        margin: 1rem auto;
        display: block;
    }
    
    .image-info {
        padding: 1rem;
        background-color: var(--bg-secondary);
        border-radius: 0.5rem;
        margin-top: 1rem;
    }
    
    hr {
        margin: 2.5rem 0;
        border-color: var(--bg-secondary);
        opacity: 0.3;
    }
    
    /* Upload Section Styling */
    .upload-section {
        background-color: var(--bg-secondary);
        padding: 2rem;
        border-radius: 1rem;
        margin: 2rem 0;
    }
</style>
""", unsafe_allow_html=True)

def load_image(image_file):
    """Load and return a PIL Image object"""
    img = Image.open(image_file)
    return img

def save_image(image_file, folder=""):
    """Save uploaded image to specified folder"""
    base_dir = "uploads"
    if folder:
        folder_path = os.path.join(base_dir, folder)
    else:
        folder_path = base_dir
        
    # Create directories if they don't exist
    os.makedirs(folder_path, exist_ok=True)
    
    # Generate unique filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{timestamp}_{image_file.name}"
    filepath = os.path.join(folder_path, filename)
    
    with open(filepath, "wb") as f:
        f.write(image_file.getbuffer())
    return filepath

def get_folder_stats(images, folders):
    """Calculate statistics for folders"""
    stats = {folder: 0 for folder in folders}
    total_size = 0
    
    for img in images:
        folder = img['folder']
        stats[folder] += 1
        if os.path.exists(img['path']):
            total_size += os.path.getsize(img['path'])
    
    return stats, total_size

def format_size(size_bytes):
    """Convert bytes to human readable format"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"

def main():
    st.title("🎨 Digital Canvas")
    st.markdown("*Where Creativity Meets Digital Space*")
    
    # Add disclaimer message with single warning icon
    st.warning("**Important:** Uploaded images will be lost if you refresh the page. Please make sure to keep your original files safe!")
    
    # Initialize session state
    if 'images' not in st.session_state:
        st.session_state.images = []
    if 'folders' not in st.session_state:
        st.session_state.folders = ["Default"]
    
    # Upload Section
    st.header("📤 Upload Images")
    selected_folder = st.selectbox("Select Folder", st.session_state.folders)
    uploaded_files = st.file_uploader("Drop images here", 
                                    type=["jpg", "jpeg", "png"], 
                                    accept_multiple_files=True)
    
    # Folder Management Section
    with st.expander("📁 Folder Management", expanded=False):
        col1, col2 = st.columns([3, 1])
        with col1:
            new_folder = st.text_input("Create New Folder")
        with col2:
            if st.button("Add Folder") and new_folder:
                if new_folder not in st.session_state.folders:
                    st.session_state.folders.append(new_folder)
                    st.success(f"Folder '{new_folder}' created!")
        
        # Folder Summary Section
        folder_stats, total_size = get_folder_stats(st.session_state.images, st.session_state.folders)
        
        st.markdown("### 📊 Folder Summary")
        
        st.markdown('<div class="folder-stats">', unsafe_allow_html=True)
        
        # Total Folders
        st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{len(st.session_state.folders)}</div>
                <div class="stat-label">Total Folders</div>
            </div>
        """, unsafe_allow_html=True)
        
        # Total Images
        st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{len(st.session_state.images)}</div>
                <div class="stat-label">Total Images</div>
            </div>
        """, unsafe_allow_html=True)
        
        # Total Size
        st.markdown(f"""
            <div class="stat-card">
                <div class="stat-number">{format_size(total_size)}</div>
                <div class="stat-label">Total Size</div>
            </div>
        """, unsafe_allow_html=True)
        
        st.markdown('</div>', unsafe_allow_html=True)
        
        # Folder Details
        if st.session_state.folders:
            st.markdown("#### 📂 Folder Details")
            for folder in st.session_state.folders:
                st.markdown(f"""
                    <div class="folder-detail">
                        📁 {folder}: {folder_stats[folder]} images
                    </div>
                """, unsafe_allow_html=True)

    # Gallery Section
    st.header("🖼️ Gallery")
    
    # Filter and Sort Options in horizontal layout
    col1, col2 = st.columns(2)
    with col1:
        view_folder = st.selectbox("📁 View Folder", ["All"] + st.session_state.folders)
    with col2:
        sort_option = st.selectbox("🔄 Sort by", ["Newest First", "Oldest First", "Filename"])
    
    # Filter images based on selected folder
    display_images = st.session_state.images
    if view_folder != "All":
        display_images = [img for img in display_images if img['folder'] == view_folder]
    
    # Sort images based on selected option
    if sort_option == "Newest First":
        display_images = sorted(display_images, key=lambda x: x['timestamp'], reverse=True)
    elif sort_option == "Oldest First":
        display_images = sorted(display_images, key=lambda x: x['timestamp'])
    elif sort_option == "Filename":
        display_images = sorted(display_images, key=lambda x: x['file'].name)

    # Process uploads with temporary confetti
    if uploaded_files:
        for uploaded_file in uploaded_files:
            if uploaded_file not in [img['file'] for img in st.session_state.images]:
                saved_path = save_image(uploaded_file, selected_folder)
                st.session_state.images.append({
                    'file': uploaded_file,
                    'path': saved_path,
                    'folder': selected_folder,
                    'timestamp': datetime.now()
                })
                st.balloons()
                time.sleep(2)
                st.rerun()

    # Display Gallery with larger images
    if st.session_state.images:
        for idx, image_data in enumerate(display_images):
            with st.container():
                st.markdown('<div class="gallery-item">', unsafe_allow_html=True)
                st.image(image_data['path'], width=None)
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.markdown(f"""
                        <div class="image-info">
                            📁 {image_data['folder']} | 
                            📅 {image_data['timestamp'].strftime('%Y-%m-%d %H:%M')}
                        </div>
                    """, unsafe_allow_html=True)
                with col2:
                    if st.button("🗑️ Remove", key=f"remove_{idx}"):
                        if os.path.exists(image_data['path']):
                            os.remove(image_data['path'])
                        st.session_state.images.remove(image_data)
                        st.rerun()
                st.markdown('</div>', unsafe_allow_html=True)
    else:
        st.info("Upload some images to get started! 📸")

if __name__ == "__main__":
    main()
